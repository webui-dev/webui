# WebUI Examples - Rust

# NOTICE: 

## The Rust wrapper still needs to be completed. You can finish it and submit the patch as PR. Or, if you prefer to maintain it in your repo, you can create a new issue and submit the link to your Rust wrapper repo. Thank you.

```sh
git clone https://github.com/alifcommunity/webui.git
cd webui\examples\Rust\hello_world
cargo clean
cargo build
cargo run
```
