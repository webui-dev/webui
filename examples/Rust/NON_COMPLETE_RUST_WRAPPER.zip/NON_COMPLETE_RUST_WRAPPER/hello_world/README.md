# WebUI Examples - Rust

```sh
git clone https://github.com/alifcommunity/webui.git
cd webui\examples\Rust\hello_world
cargo clean
cargo build
cargo run
```
